package com.pygly.eqadautologin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.RenderLayer;

/**
 * 极简图标按钮:只负责把一个已经准备好、已经绑定好的贴图 Identifier 画出来。
 * 贴图从哪里来、怎么加载,完全不归这个类管,由调用方(EQADAutoLogin)负责
 * 通过外部文件 + NativeImageBackedTexture 手动注册好之后再传进来。
 */
public class IconButton extends ButtonWidget {
    private final Identifier texture;

    public IconButton(int x, int y, int size, Identifier texture, Text tooltipText, PressAction onPress) {
        super(x, y, size, size, Text.empty(), onPress, DEFAULT_NARRATION_SUPPLIER);
        this.texture = texture;
        this.setTooltip(Tooltip.of(tooltipText));
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        super.renderWidget(context, mouseX, mouseY, delta);
        if (texture != null) {
            RenderSystem.setShaderTexture(0, texture);

context.drawTexture(
        RenderLayer::getGuiTextured,
        texture,
        this.getX(),
        this.getY(),
        0,
        0,
        this.getWidth(),
        this.getHeight(),
        this.getWidth(),
        this.getHeight()
);
        }
    }
}