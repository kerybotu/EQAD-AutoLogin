# EQAD AutoLogin

<img width="870" height="129" alt="image" src="https://github.com/user-attachments/assets/0a20242e-c5d5-4266-8534-36e834117501" />

### 为 EQAD 纯净服量身打造的丝滑自动登录客户端MOD  
**再也不用手动打 `/l 密码` 了！1 秒丝滑登录，密码永不泄露！**

<p align="center">
    <img width="1024" height="1024" alt="icon" src="https://github.com/user-attachments/assets/f9994cc7-8f5b-481b-ae80-c7f28698c974" width="150"/>
</p>

<div align="center">
    <a href="https://minecraft.net"><img src="https://img.shields.io/badge/Minecraft-1.21.4-62b47a?style=for-the-badge&logo=minecraft" alt="Minecraft" /></a>
    <a href="https://fabricmc.net"><img src="https://img.shields.io/badge/Fabric-Loader-F16436?style=for-the-badge&logo=fabricmc" alt="Fabric" /></a>
    <a href="LICENSE"><img src="https://img.shields.io/github/license/kerybotu/EQAD-AutoLogin?color=blue&style=for-the-badge" alt="License" /></a>
    <a href="https://github.com/kerybotu/EQAD-AutoLogin/stargazers"><img src="https://img.shields.io/github/stars/kerybotu/EQAD-AutoLogin?style=social" alt="Stars" /></a>
</div>

## 特性亮点

1秒自动登录:          支持

多账号完全隔离:       支持（每个账号独立目录 + 独立密钥）

AES本地加密:         支持（即使本地游戏文件文件被复制也无法解密）

密码输入黑点显示:     支持（●●●● 防窥）

配置存放用户目录:     支持（C:user/username/.eqadautologin/玩家名/）

完全开源 MIT

支持版本：1.21.x

<img width="773" height="478" alt="image" src="https://github.com/user-attachments/assets/cf00174e-71f4-4cc0-b57b-7e58a3fac7a2" />

<img width="781" height="178" alt="image" src="https://github.com/user-attachments/assets/cf53ed6f-056d-4121-a706-5b5c70e407ab" />


支持服务器（自动识别）:

    - vanilla.eqad.fun
    
    - vanilla-v6.eqad.fun
    
    - vanilla-1.eqad.fun
    
    - vanilla-2.eqad.fun
    
    - vanilla-3.eqad.fun
    
只要地址匹配，即可自动登录！

## 安装方法

1.安装 **Fabric Loader**（推荐 0.16+ 版本）

2. 下载 **EQAD-AutoLogin-x.x.x.jar** 文件
   
3.将其放入 `.minecraft/mods/` 文件夹中

4.启动游戏 → 首次进入服务器会自动弹出密码设置窗口

5.输入你的 `密码` → 确定 → 以后再也不用手动输入了！

## 安全声明

密码永不上传任何服务器

密码本地AES加密存储

每个账号独立密钥，彻底隔离

源代码完全开源，可随时审计
